# College CRM Management System

A complete, working college management system built with **Python Django**, covering students,
faculty, departments, admissions/academics, attendance, marks, fees, complaints, announcements,
events, and in-app notifications — all from role-based dashboards.

## Tech Stack

- **Backend:** Python 3.10+, Django 5
- **Frontend:** HTML5, CSS3 (custom design system), Bootstrap 5 (grid/utilities/components), vanilla JS
- **Database:** SQLite (via Django ORM) — zero manual setup, migrations build the schema
- **Auth:** Django's built-in auth system with a custom `User` model and role-based access control

## Roles

| Role | Highlights |
|---|---|
| **Super Admin** | Full dashboard, manage students/faculty/departments/courses/subjects/fees/complaints/announcements/events/users, reports |
| **HOD** | Department dashboard, manage faculty & students within the department, attendance/performance stats, complaints |
| **Faculty** | View assigned subjects & students, mark attendance, enter marks, post announcements, respond to complaints |
| **Student** | Register/login, profile, attendance %, marks, subjects, fee status + mock payment, complaints, announcements, events |

## Project Structure

```
college_crm/
├── manage.py
├── requirements.txt
├── college_crm/          # project settings, root urls, wsgi/asgi
├── accounts/              # custom User model, auth, roles
├── core/                  # home page, role-based dashboards, generate_demo_data command
├── academics/              # Department, Course, AcademicYear, Semester, Subject
├── students/               # Student profile & management
├── faculty/                 # Faculty profile & management
├── attendance/               # Attendance marking & reporting
├── marks/                     # Internal/assignment/lab/practical/exam marks
├── fees/                       # Fee records + mock payment gateway
├── complaints/                  # Complaints + status timeline
├── announcements/                 # Targeted announcements
├── events/                          # Events + registration
├── notifications/                    # In-app notification system
├── templates/                          # All HTML templates (Bootstrap 5 based)
├── static/                              # CSS/JS
└── media/                                 # Uploaded profile photos, posters, attachments
```

## Setup & Run Instructions (VS Code)

1. **Open the project folder in VS Code**
   `File → Open Folder…` → select the extracted `college_crm` folder.

2. **Create and activate a virtual environment** (open a terminal in VS Code: `` Ctrl+` ``)

   ```bash
   python -m venv venv
   ```

   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`

   VS Code may prompt "Select Interpreter" — choose the `venv` one.

3. **Install dependencies**

   ```bash
   pip install -r requirements.txt
   ```

4. **Create the database (migrations build the schema automatically — no manual SQL needed)**

   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Generate demo data** (creates admin, HOD, faculty, and student accounts plus departments,
   courses, subjects, attendance, marks, fees, complaints, announcements, and events)

   ```bash
   python manage.py generate_demo_data
   ```

   Optional: control how many students are generated per department (default 8):

   ```bash
   python manage.py generate_demo_data --students-per-dept 12
   ```

6. **Run the development server**

   ```bash
   python manage.py runserver
   ```

7. **Open the app** in your browser at [http://127.0.0.1:8000/](http://127.0.0.1:8000/)

   Django admin is available at [http://127.0.0.1:8000/admin/](http://127.0.0.1:8000/admin/)

## Demo Login Credentials

After running `generate_demo_data`:

| Role | Username | Password |
|---|---|---|
| Super Admin | `admin` | `admin123` |
| HOD (CSE) | `hod_cse` | `hod123` |
| Faculty | `faculty1` | `faculty123` |
| Student | `student1` | `student123` |

Additional demo faculty/student accounts follow the pattern `faculty_<deptcode>_<n>` /
`stu_<deptcode>_<n>` with passwords `faculty123` / `student123` respectively (department codes:
`CSE`, `IT`, `AIDS`, `ECE`, `EEE`, `MECH`, `CIVIL`).

New students can also self-register from the login page (`Register here`), which creates a
`STUDENT`-role account automatically. An admin/HOD can then complete their department/course/year
assignment from the Students module.

## Key Feature Notes

- **Auto-generated IDs:** Students get `STU<year><####>` (e.g. `STU20260001`), Faculty get
  `FAC<year><####>`, and Complaints get `CMP<year><####>` — all generated automatically on save.
- **Fees:** A **mock payment system** is used (no real payment gateway integration) — payments are
  recorded instantly with a generated transaction ID, purely for demonstration.
- **Notifications:** In-app notifications are created automatically when attendance is marked,
  marks are published, complaint status changes, a new announcement/event is posted, or a fee is
  added — with an unread-count badge in the top bar.
- **Role-based access:** Enforced via decorators in `accounts/decorators.py`
  (`admin_required`, `staff_required`, `admin_or_hod_required`, `student_required`) — students
  cannot reach faculty/admin-only views.
- **Search & filters:** Available on Students (ID/name, department, year), Faculty (name/ID,
  department), Complaints (ID, status, priority), Subjects, and Attendance (subject, date).

## Resetting the Demo Data

To start over, delete `db.sqlite3` and the `media/` contents, then re-run:

```bash
python manage.py migrate
python manage.py generate_demo_data
```

## Notes

- `DEBUG = True` and a hard-coded `SECRET_KEY` are used for local/demo purposes only — change both
  before any real deployment, and set `DEBUG = False` with a proper `ALLOWED_HOSTS` list.
- Uploaded files (profile photos, event posters, announcement attachments) are stored under
  `/media/` and served by Django's dev server only while `DEBUG = True`.
