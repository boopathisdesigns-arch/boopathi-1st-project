from django.db import models
from django.conf import settings
from django.utils import timezone
from students.models import Student


def generate_complaint_id():
    year = timezone.now().year
    prefix = f"CMP{year}"
    last = Complaint.objects.filter(complaint_id__startswith=prefix).order_by("-complaint_id").first()
    if last:
        last_num = int(last.complaint_id.replace(prefix, ""))
        new_num = last_num + 1
    else:
        new_num = 1
    return f"{prefix}{new_num:04d}"


class Complaint(models.Model):
    CATEGORY_CHOICES = [
        ("HOSTEL", "Hostel"), ("TRANSPORT", "Transport"), ("ELECTRICAL", "Electrical"),
        ("PLUMBING", "Plumbing"), ("IT", "IT"), ("CLASSROOM", "Classroom"),
        ("FACULTY", "Faculty"), ("SECURITY", "Security"), ("CLEANING", "Cleaning"), ("OTHER", "Other"),
    ]
    STATUS_CHOICES = [
        ("PENDING", "Pending"), ("ASSIGNED", "Assigned"), ("IN_PROGRESS", "In Progress"),
        ("RESOLVED", "Resolved"), ("REJECTED", "Rejected"),
    ]
    PRIORITY_CHOICES = [("LOW", "Low"), ("MEDIUM", "Medium"), ("HIGH", "High"), ("URGENT", "Urgent")]

    complaint_id = models.CharField(max_length=20, unique=True, blank=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="complaints")
    category = models.CharField(max_length=15, choices=CATEGORY_CHOICES)
    subject = models.CharField(max_length=200)
    description = models.TextField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default="MEDIUM")
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="PENDING")
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="assigned_complaints"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        if not self.complaint_id:
            self.complaint_id = generate_complaint_id()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.complaint_id} - {self.subject}"


class ComplaintHistory(models.Model):
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name="history")
    status = models.CharField(max_length=15, choices=Complaint.STATUS_CHOICES)
    remarks = models.TextField(blank=True)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["changed_at"]
        verbose_name_plural = "Complaint histories"

    def __str__(self):
        return f"{self.complaint.complaint_id} -> {self.status}"
