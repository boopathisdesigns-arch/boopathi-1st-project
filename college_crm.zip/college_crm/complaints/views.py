from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from accounts.decorators import staff_required, student_required
from notifications.utils import notify_user
from .models import Complaint, ComplaintHistory
from .forms import ComplaintForm, ComplaintUpdateForm


@login_required
def complaint_list(request):
    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        complaints = Complaint.objects.filter(student=student) if student else Complaint.objects.none()
    else:
        complaints = Complaint.objects.select_related("student", "assigned_to").all()

    status = request.GET.get("status", "")
    priority = request.GET.get("priority", "")
    query = request.GET.get("q", "")

    if status:
        complaints = complaints.filter(status=status)
    if priority:
        complaints = complaints.filter(priority=priority)
    if query:
        complaints = complaints.filter(complaint_id__icontains=query)

    return render(request, "complaints/complaint_list.html", {
        "complaints": complaints, "status_choices": Complaint.STATUS_CHOICES,
        "priority_choices": Complaint.PRIORITY_CHOICES, "selected_status": status,
        "selected_priority": priority, "query": query,
    })


@student_required
def complaint_create(request):
    if request.method == "POST":
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.student = request.user.student_profile
            complaint.save()
            ComplaintHistory.objects.create(complaint=complaint, status="PENDING", changed_by=request.user, remarks="Complaint submitted.")
            messages.success(request, f"Complaint {complaint.complaint_id} submitted successfully.")
            return redirect("complaints:complaint_detail", pk=complaint.pk)
    else:
        form = ComplaintForm()
    return render(request, "complaints/complaint_form.html", {"form": form})


@login_required
def complaint_detail(request, pk):
    complaint = get_object_or_404(Complaint.objects.select_related("student", "assigned_to"), pk=pk)
    if request.user.is_student_role and complaint.student.user != request.user:
        messages.error(request, "Not authorized.")
        return redirect("core:dashboard")

    update_form = None
    if not request.user.is_student_role:
        if request.method == "POST":
            update_form = ComplaintUpdateForm(request.POST, instance=complaint)
            if update_form.is_valid():
                updated = update_form.save()
                ComplaintHistory.objects.create(
                    complaint=updated, status=updated.status, changed_by=request.user,
                    remarks=update_form.cleaned_data.get("remarks", ""),
                )
                notify_user(updated.student.user, f"Your complaint {updated.complaint_id} status changed to {updated.get_status_display()}.", category="COMPLAINT")
                messages.success(request, "Complaint updated.")
                return redirect("complaints:complaint_detail", pk=complaint.pk)
        else:
            update_form = ComplaintUpdateForm(instance=complaint)

    return render(request, "complaints/complaint_detail.html", {
        "complaint": complaint, "history": complaint.history.all(), "update_form": update_form,
    })
