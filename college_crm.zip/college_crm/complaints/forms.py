from academics.forms import BootstrapModelForm
from django import forms
from .models import Complaint


class ComplaintForm(BootstrapModelForm):
    class Meta:
        model = Complaint
        fields = ["category", "subject", "description", "priority"]
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}


class ComplaintUpdateForm(BootstrapModelForm):
    remarks = forms.CharField(widget=forms.Textarea(attrs={"class": "form-control", "rows": 3}), required=False)

    class Meta:
        model = Complaint
        fields = ["status", "assigned_to", "remarks"]
