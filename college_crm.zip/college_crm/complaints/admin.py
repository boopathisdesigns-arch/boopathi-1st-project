from django.contrib import admin
from .models import Complaint, ComplaintHistory


class ComplaintHistoryInline(admin.TabularInline):
    model = ComplaintHistory
    extra = 0


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ("complaint_id", "student", "category", "priority", "status", "created_at")
    list_filter = ("category", "status", "priority")
    search_fields = ("complaint_id", "subject")
    inlines = [ComplaintHistoryInline]
