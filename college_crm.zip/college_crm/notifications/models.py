from django.db import models
from django.conf import settings


class Notification(models.Model):
    CATEGORY_CHOICES = [
        ("ATTENDANCE", "Attendance"), ("MARKS", "Marks"), ("COMPLAINT", "Complaint"),
        ("ANNOUNCEMENT", "Announcement"), ("FEE", "Fee"), ("EVENT", "Event"), ("GENERAL", "General"),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    message = models.CharField(max_length=255)
    category = models.CharField(max_length=15, choices=CATEGORY_CHOICES, default="GENERAL")
    link = models.CharField(max_length=255, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user} - {self.message[:30]}"
