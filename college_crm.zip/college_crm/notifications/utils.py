from .models import Notification


def notify_user(user, message, category="GENERAL", link=""):
    """Create a notification for a single user."""
    if user is None:
        return None
    return Notification.objects.create(user=user, message=message, category=category, link=link)


def notify_many(users, message, category="GENERAL", link=""):
    """Create the same notification for many users at once."""
    Notification.objects.bulk_create([
        Notification(user=u, message=message, category=category, link=link) for u in users if u is not None
    ])
