from academics.forms import BootstrapModelForm
from .models import Mark


class MarkForm(BootstrapModelForm):
    class Meta:
        model = Mark
        fields = [
            "student", "subject", "internal_marks", "assignment_marks", "lab_marks",
            "practical_marks", "semester_exam_marks", "max_internal", "max_assignment",
            "max_lab", "max_practical", "max_semester_exam",
        ]
