from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from accounts.decorators import staff_required
from academics.models import Subject
from students.models import Student
from notifications.utils import notify_user
from .models import Mark
from .forms import MarkForm


@login_required
def marks_list(request):
    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        marks = Mark.objects.filter(student=student).select_related("subject") if student else Mark.objects.none()
    else:
        marks = Mark.objects.select_related("student", "subject").all()
        if request.user.role in ("FACULTY", "HOD"):
            marks = marks.filter(subject__faculty=request.user)
        subject_id = request.GET.get("subject", "")
        if subject_id:
            marks = marks.filter(subject_id=subject_id)

    return render(request, "marks/marks_list.html", {
        "marks": marks, "subjects": Subject.objects.all(),
        "selected_subject": request.GET.get("subject", ""),
    })


@staff_required
def marks_entry(request):
    subject_id = request.GET.get("subject") or request.POST.get("subject")
    subject = None
    students = []
    subjects = Subject.objects.all()
    if request.user.role in ("FACULTY", "HOD"):
        subjects = subjects.filter(faculty=request.user)

    if subject_id:
        subject = get_object_or_404(Subject, pk=subject_id)
        students = Student.objects.filter(course=subject.course, semester=subject.semester_number, is_active=True).select_related("user")

    if request.method == "POST" and subject:
        for student in students:
            def gv(field):
                val = request.POST.get(f"{field}_{student.pk}", "0")
                return val or "0"
            mark, created = Mark.objects.update_or_create(
                student=student, subject=subject,
                defaults={
                    "internal_marks": gv("internal"),
                    "assignment_marks": gv("assignment"),
                    "lab_marks": gv("lab"),
                    "practical_marks": gv("practical"),
                    "semester_exam_marks": gv("semester_exam"),
                    "entered_by": request.user,
                },
            )
            notify_user(student.user, f"Marks for {subject.name} have been published.", category="MARKS")
        messages.success(request, f"Marks saved for {subject.name}.")
        return redirect(f"/marks/entry/?subject={subject.pk}")

    existing = {}
    if subject:
        existing = {m.student_id: m for m in Mark.objects.filter(subject=subject)}

    return render(request, "marks/marks_entry.html", {
        "subjects": subjects, "subject": subject, "students": students, "existing": existing,
    })
