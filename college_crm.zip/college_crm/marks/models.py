from django.db import models
from django.conf import settings
from students.models import Student
from academics.models import Subject


class Mark(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="marks")
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name="marks")

    internal_marks = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    assignment_marks = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    lab_marks = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    practical_marks = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    semester_exam_marks = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    max_internal = models.DecimalField(max_digits=5, decimal_places=2, default=20)
    max_assignment = models.DecimalField(max_digits=5, decimal_places=2, default=10)
    max_lab = models.DecimalField(max_digits=5, decimal_places=2, default=20)
    max_practical = models.DecimalField(max_digits=5, decimal_places=2, default=20)
    max_semester_exam = models.DecimalField(max_digits=5, decimal_places=2, default=30)

    entered_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("student", "subject")
        ordering = ["-updated_at"]

    def __str__(self):
        return f"{self.student.student_id} - {self.subject.code}"

    @property
    def total_obtained(self):
        return (self.internal_marks + self.assignment_marks + self.lab_marks +
                self.practical_marks + self.semester_exam_marks)

    @property
    def total_max(self):
        return (self.max_internal + self.max_assignment + self.max_lab +
                self.max_practical + self.max_semester_exam)

    @property
    def percentage(self):
        if self.total_max == 0:
            return 0
        return round(float(self.total_obtained) / float(self.total_max) * 100, 2)

    @property
    def grade(self):
        pct = self.percentage
        if pct >= 90:
            return "A+"
        if pct >= 80:
            return "A"
        if pct >= 70:
            return "B+"
        if pct >= 60:
            return "B"
        if pct >= 50:
            return "C"
        if pct >= 40:
            return "D"
        return "F"
