from django.contrib import admin
from .models import Mark


@admin.register(Mark)
class MarkAdmin(admin.ModelAdmin):
    list_display = ("student", "subject", "total_obtained", "total_max", "percentage", "grade")
    list_filter = ("subject",)
    search_fields = ("student__student_id",)
