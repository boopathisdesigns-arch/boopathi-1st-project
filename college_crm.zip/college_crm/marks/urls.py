from django.urls import path
from . import views

app_name = "marks"

urlpatterns = [
    path("", views.marks_list, name="marks_list"),
    path("entry/", views.marks_entry, name="marks_entry"),
]
