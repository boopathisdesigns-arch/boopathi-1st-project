from django import forms
from academics.forms import BootstrapModelForm
from .models import Event


class EventForm(BootstrapModelForm):
    class Meta:
        model = Event
        fields = ["name", "description", "date", "time", "venue", "organizer", "registration_deadline", "poster"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            "date": forms.DateInput(attrs={"type": "date"}),
            "time": forms.TimeInput(attrs={"type": "time"}),
            "registration_deadline": forms.DateInput(attrs={"type": "date"}),
        }
