from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils import timezone

from accounts.decorators import admin_required, student_required
from notifications.utils import notify_many
from .models import Event, EventRegistration
from .forms import EventForm


@login_required
def event_list(request):
    events = Event.objects.all()
    upcoming = events.filter(date__gte=timezone.now().date())
    past = events.filter(date__lt=timezone.now().date())
    return render(request, "events/event_list.html", {"events": events, "upcoming": upcoming, "past": past})


@admin_required
def event_create(request):
    if request.method == "POST":
        form = EventForm(request.POST, request.FILES)
        if form.is_valid():
            event = form.save(commit=False)
            event.created_by = request.user
            event.save()

            from students.models import Student
            notify_many([s.user for s in Student.objects.all()], f"New event announced: {event.name} on {event.date}.", category="EVENT")

            messages.success(request, "Event created successfully.")
            return redirect("events:event_list")
    else:
        form = EventForm()
    return render(request, "events/event_form.html", {"form": form})


@login_required
def event_detail(request, pk):
    event = get_object_or_404(Event, pk=pk)
    is_registered = False
    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        is_registered = student and EventRegistration.objects.filter(event=event, student=student).exists()
    return render(request, "events/event_detail.html", {"event": event, "is_registered": is_registered})


@student_required
def event_register(request, pk):
    event = get_object_or_404(Event, pk=pk)
    student = request.user.student_profile
    if not event.registration_open:
        messages.error(request, "Registration is closed for this event.")
    else:
        _, created = EventRegistration.objects.get_or_create(event=event, student=student)
        if created:
            messages.success(request, f"You are registered for {event.name}.")
        else:
            messages.info(request, "You are already registered for this event.")
    return redirect("events:event_detail", pk=event.pk)


@admin_required
def event_delete(request, pk):
    event = get_object_or_404(Event, pk=pk)
    if request.method == "POST":
        event.delete()
        messages.success(request, "Event deleted.")
        return redirect("events:event_list")
    return render(request, "core/confirm_delete.html", {"object": event, "cancel_url": "events:event_list"})
