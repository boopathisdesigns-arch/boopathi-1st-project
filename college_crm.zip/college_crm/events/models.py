from django.db import models
from django.conf import settings
from django.utils import timezone


class Event(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateField()
    time = models.TimeField()
    venue = models.CharField(max_length=200)
    organizer = models.CharField(max_length=150)
    registration_deadline = models.DateField(null=True, blank=True)
    poster = models.ImageField(upload_to="events/", blank=True, null=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["date", "time"]

    def __str__(self):
        return self.name

    @property
    def is_upcoming(self):
        return self.date >= timezone.now().date()

    @property
    def registration_open(self):
        if not self.registration_deadline:
            return self.is_upcoming
        return timezone.now().date() <= self.registration_deadline

    @property
    def registration_count(self):
        return self.registrations.count()


class EventRegistration(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="registrations")
    student = models.ForeignKey("students.Student", on_delete=models.CASCADE, related_name="event_registrations")
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("event", "student")
        ordering = ["-registered_at"]

    def __str__(self):
        return f"{self.student.student_id} -> {self.event.name}"
