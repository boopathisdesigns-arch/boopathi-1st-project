from django.contrib import admin
from .models import Announcement


@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ("title", "department", "target_year", "priority", "date", "posted_by")
    list_filter = ("priority", "department")
    search_fields = ("title",)
