from django.db import models
from django.conf import settings
from academics.models import Department


class Announcement(models.Model):
    PRIORITY_CHOICES = [("LOW", "Low"), ("NORMAL", "Normal"), ("HIGH", "High"), ("URGENT", "Urgent")]
    YEAR_CHOICES = [(0, "All Years"), (1, "1st Year"), (2, "2nd Year"), (3, "3rd Year"), (4, "4th Year")]

    title = models.CharField(max_length=200)
    description = models.TextField()
    department = models.ForeignKey(Department, on_delete=models.CASCADE, null=True, blank=True, related_name="announcements", help_text="Leave blank for college-wide")
    target_year = models.PositiveSmallIntegerField(choices=YEAR_CHOICES, default=0)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default="NORMAL")
    attachment = models.FileField(upload_to="announcements/", blank=True, null=True)
    posted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date"]

    def __str__(self):
        return self.title
