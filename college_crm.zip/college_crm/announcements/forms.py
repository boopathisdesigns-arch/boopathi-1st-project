from django import forms
from academics.forms import BootstrapModelForm
from .models import Announcement


class AnnouncementForm(BootstrapModelForm):
    class Meta:
        model = Announcement
        fields = ["title", "description", "department", "target_year", "priority", "attachment"]
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}
