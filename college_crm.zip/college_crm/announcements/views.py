from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from accounts.decorators import staff_required
from notifications.utils import notify_many
from .models import Announcement
from .forms import AnnouncementForm


@login_required
def announcement_list(request):
    announcements = Announcement.objects.select_related("department", "posted_by").all()
    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        if student:
            announcements = announcements.filter(
                department__isnull=True
            ) | announcements.filter(department=student.department)
            announcements = announcements.filter(
                target_year=0
            ) | announcements.filter(target_year=student.year)
    query = request.GET.get("q", "")
    if query:
        announcements = announcements.filter(title__icontains=query)
    return render(request, "announcements/announcement_list.html", {
        "announcements": announcements.distinct(), "query": query,
    })


@staff_required
def announcement_create(request):
    if request.method == "POST":
        form = AnnouncementForm(request.POST, request.FILES)
        if form.is_valid():
            announcement = form.save(commit=False)
            announcement.posted_by = request.user
            announcement.save()

            from students.models import Student
            targets = Student.objects.all()
            if announcement.department:
                targets = targets.filter(department=announcement.department)
            if announcement.target_year:
                targets = targets.filter(year=announcement.target_year)
            notify_many([s.user for s in targets], f"New announcement: {announcement.title}", category="ANNOUNCEMENT")

            messages.success(request, "Announcement posted successfully.")
            return redirect("announcements:announcement_list")
    else:
        form = AnnouncementForm()
    return render(request, "announcements/announcement_form.html", {"form": form})


@login_required
def announcement_detail(request, pk):
    announcement = get_object_or_404(Announcement, pk=pk)
    return render(request, "announcements/announcement_detail.html", {"announcement": announcement})


@staff_required
def announcement_delete(request, pk):
    announcement = get_object_or_404(Announcement, pk=pk)
    if request.method == "POST":
        announcement.delete()
        messages.success(request, "Announcement deleted.")
        return redirect("announcements:announcement_list")
    return render(request, "core/confirm_delete.html", {"object": announcement, "cancel_url": "announcements:announcement_list"})
