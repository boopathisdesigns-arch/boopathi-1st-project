from django.contrib import admin

# nothing to register for core

