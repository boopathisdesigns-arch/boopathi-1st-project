from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Q
from django.utils import timezone

from students.models import Student
from faculty.models import Faculty
from academics.models import Department, Subject
from attendance.models import Attendance
from marks.models import Mark
from fees.models import Fee
from complaints.models import Complaint
from announcements.models import Announcement
from events.models import Event


def home(request):
    if request.user.is_authenticated:
        return redirect("core:dashboard")
    return render(request, "core/home.html")


@login_required
def dashboard(request):
    user = request.user

    if user.is_admin_role:
        return _admin_dashboard(request)
    elif user.role == "HOD":
        return _hod_dashboard(request)
    elif user.role == "FACULTY":
        return _faculty_dashboard(request)
    else:
        return _student_dashboard(request)


def _admin_dashboard(request):
    total_students = Student.objects.count()
    total_faculty = Faculty.objects.count()
    total_departments = Department.objects.count()
    total_complaints = Complaint.objects.count()
    pending_complaints = Complaint.objects.filter(status__in=["PENDING", "ASSIGNED", "IN_PROGRESS"]).count()
    resolved_complaints = Complaint.objects.filter(status="RESOLVED").count()

    fees_total = Fee.objects.aggregate(t=Sum("total_amount"))["t"] or 0
    fee_collection = sum(f.paid_amount for f in Fee.objects.all())
    pending_fees = fees_total - fee_collection

    total_att = Attendance.objects.count()
    present_att = Attendance.objects.filter(status="PRESENT").count()
    attendance_pct = round((present_att / total_att) * 100, 1) if total_att else 0

    dept_stats = Department.objects.annotate(student_count=Count("students")).order_by("-student_count")[:7]

    recent_announcements = Announcement.objects.all()[:5]
    upcoming_events = Event.objects.filter(date__gte=timezone.now().date())[:5]

    context = {
        "total_students": total_students,
        "total_faculty": total_faculty,
        "total_departments": total_departments,
        "total_complaints": total_complaints,
        "pending_complaints": pending_complaints,
        "resolved_complaints": resolved_complaints,
        "fee_collection": fee_collection,
        "pending_fees": pending_fees,
        "fees_total": fees_total,
        "attendance_pct": attendance_pct,
        "dept_stats": dept_stats,
        "recent_announcements": recent_announcements,
        "upcoming_events": upcoming_events,
    }
    return render(request, "core/dashboard_admin.html", context)


def _hod_dashboard(request):
    user = request.user
    department = Department.objects.filter(hod=user).first()
    students = Student.objects.filter(department=department) if department else Student.objects.none()
    faculty = Faculty.objects.filter(department=department) if department else Faculty.objects.none()
    complaints = Complaint.objects.filter(student__department=department) if department else Complaint.objects.none()

    total_att = Attendance.objects.filter(student__department=department).count() if department else 0
    present_att = Attendance.objects.filter(student__department=department, status="PRESENT").count() if department else 0
    attendance_pct = round((present_att / total_att) * 100, 1) if total_att else 0

    avg_marks = Mark.objects.filter(student__department=department).count() if department else 0

    context = {
        "department": department,
        "total_students": students.count(),
        "total_faculty": faculty.count(),
        "total_complaints": complaints.count(),
        "pending_complaints": complaints.filter(status__in=["PENDING", "ASSIGNED", "IN_PROGRESS"]).count(),
        "attendance_pct": attendance_pct,
        "recent_complaints": complaints[:5],
    }
    return render(request, "core/dashboard_hod.html", context)


def _faculty_dashboard(request):
    user = request.user
    subjects = Subject.objects.filter(faculty=user)
    student_ids = Student.objects.filter(course__in=subjects.values("course")).distinct()
    marks_pending = Mark.objects.filter(subject__in=subjects).count()

    context = {
        "subjects": subjects,
        "total_students": student_ids.count(),
        "total_subjects": subjects.count(),
        "marks_entered": marks_pending,
        "recent_announcements": Announcement.objects.all()[:5],
    }
    return render(request, "core/dashboard_faculty.html", context)


def _student_dashboard(request):
    user = request.user
    student = getattr(user, "student_profile", None)
    if not student:
        return render(request, "core/dashboard_student.html", {"no_profile": True})

    attendance_qs = Attendance.objects.filter(student=student)
    total_att = attendance_qs.count()
    present_att = attendance_qs.filter(status="PRESENT").count()
    attendance_pct = round((present_att / total_att) * 100, 1) if total_att else 0

    recent_marks = Mark.objects.filter(student=student).select_related("subject")[:5]
    fees = Fee.objects.filter(student=student)
    pending_fees = sum(f.pending_amount for f in fees)

    announcements = Announcement.objects.filter(
        Q(department__isnull=True) | Q(department=student.department)
    ).filter(Q(target_year=0) | Q(target_year=student.year)).distinct()[:5]

    upcoming_events = Event.objects.filter(date__gte=timezone.now().date())[:5]
    complaints = Complaint.objects.filter(student=student)[:5]

    context = {
        "student": student,
        "attendance_pct": attendance_pct,
        "recent_marks": recent_marks,
        "pending_fees": pending_fees,
        "announcements": announcements,
        "upcoming_events": upcoming_events,
        "complaints": complaints,
    }
    return render(request, "core/dashboard_student.html", context)
