from django.db import models

# core app has no models of its own — it hosts shared dashboard/home views.

