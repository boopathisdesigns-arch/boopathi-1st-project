import random
from datetime import timedelta, date

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from accounts.models import User
from academics.models import Department, Course, AcademicYear, Semester, Subject
from students.models import Student
from faculty.models import Faculty
from attendance.models import Attendance
from marks.models import Mark
from fees.models import Fee, FeePayment
from complaints.models import Complaint, ComplaintHistory
from announcements.models import Announcement
from events.models import Event, EventRegistration


FIRST_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Krishna", "Ishaan", "Rohan",
    "Ananya", "Diya", "Saanvi", "Aadhya", "Kavya", "Myra", "Sara", "Riya", "Ira", "Anika",
    "Rahul", "Neha", "Priya", "Karan", "Sneha", "Amit", "Pooja", "Vikram", "Divya", "Nikhil",
    "Meera", "Aryan", "Tara", "Dev", "Isha", "Yash", "Kiara", "Rudra", "Zara", "Advait",
]
LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Iyer", "Nair", "Menon", "Reddy", "Rao", "Patel", "Shah",
    "Kapoor", "Mehta", "Joshi", "Chatterjee", "Bose", "Das", "Pillai", "Chauhan", "Malhotra", "Bhat",
]

DEPARTMENTS = [
    ("Computer Science Engineering", "CSE"),
    ("Information Technology", "IT"),
    ("AI & Data Science", "AIDS"),
    ("Electronics & Communication", "ECE"),
    ("Electrical & Electronics", "EEE"),
    ("Mechanical Engineering", "MECH"),
    ("Civil Engineering", "CIVIL"),
]

COMPLAINT_SUBJECTS = {
    "HOSTEL": "Water leakage in hostel room",
    "TRANSPORT": "College bus arriving late",
    "ELECTRICAL": "Power socket not working in lab",
    "PLUMBING": "Washroom tap is broken",
    "IT": "Wi-Fi not working in library",
    "CLASSROOM": "Projector not functioning",
    "FACULTY": "Request for extra doubt-clearing session",
    "SECURITY": "ID card scanner malfunctioning at gate",
    "CLEANING": "Classroom not cleaned regularly",
    "OTHER": "General feedback about campus facilities",
}


class Command(BaseCommand):
    help = "Generate realistic demo data for the College CRM (idempotent-ish; safe to re-run on a fresh DB)."

    def add_arguments(self, parser):
        parser.add_argument("--students-per-dept", type=int, default=8, help="Number of students to create per department")

    @transaction.atomic
    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING("Generating demo data for College CRM..."))
        students_per_dept = options["students_per_dept"]

        academic_year, hod_users, departments, courses = self.create_academics()
        faculty_users = self.create_faculty(departments)
        self.assign_hods(departments, faculty_users)
        subjects = self.create_subjects(departments, courses, faculty_users)
        students = self.create_students(departments, courses, academic_year, students_per_dept)
        self.create_attendance(students, subjects)
        self.create_marks(students, subjects)
        self.create_fees(students, academic_year)
        self.create_complaints(students, faculty_users)
        self.create_announcements(departments, faculty_users)
        self.create_events(students)
        self.create_admin()

        self.stdout.write(self.style.SUCCESS("\nDemo data generated successfully!"))
        self.print_credentials()

    # ---------------------------------------------------------------
    def unique_username(self, base):
        username = base
        i = 1
        while User.objects.filter(username=username).exists():
            i += 1
            username = f"{base}{i}"
        return username

    def create_admin(self):
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser(
                username="admin", email="admin@collegecrm.edu", password="admin123",
                first_name="System", last_name="Administrator", role=User.Role.ADMIN,
            )

    # ---------------------------------------------------------------
    def create_academics(self):
        today = timezone.now().date()
        academic_year, _ = AcademicYear.objects.get_or_create(
            name="2026-2027",
            defaults={"start_date": date(2026, 7, 1), "end_date": date(2027, 5, 31), "is_current": True},
        )
        for n in range(1, 9):
            Semester.objects.get_or_create(number=n, academic_year=academic_year, defaults={"is_active": n <= 2})

        departments = []
        courses = []
        for name, code in DEPARTMENTS:
            dept, _ = Department.objects.get_or_create(name=name, defaults={"code": code})
            departments.append(dept)
            course, _ = Course.objects.get_or_create(
                name=f"B.Tech {name}", code=f"BT-{code}", department=dept, defaults={"duration_years": 4}
            )
            courses.append(course)
        return academic_year, [], departments, courses

    def create_faculty(self, departments):
        designations = ["PROF", "ASSOC", "ASST", "LECT"]
        faculty_users = {dept.code: [] for dept in departments}
        for dept in departments:
            for i in range(3):
                first = random.choice(FIRST_NAMES)
                last = random.choice(LAST_NAMES)
                username = self.unique_username(f"faculty_{dept.code.lower()}_{i+1}")
                if i == 0 and dept.code == "CSE":
                    username = "faculty1"
                user, created = User.objects.get_or_create(
                    username=username,
                    defaults={
                        "first_name": first, "last_name": last, "email": f"{username}@collegecrm.edu",
                        "role": User.Role.FACULTY, "phone": f"98{random.randint(10000000, 99999999)}",
                    },
                )
                if created:
                    user.set_password("faculty123")
                    user.save()
                Faculty.objects.get_or_create(
                    user=user,
                    defaults={
                        "department": dept, "designation": random.choice(designations),
                        "joining_date": date(random.randint(2015, 2024), random.randint(1, 12), 1),
                        "qualification": random.choice(["M.Tech", "Ph.D", "M.E", "M.S"]),
                    },
                )
                faculty_users[dept.code].append(user)
        return faculty_users

    def assign_hods(self, departments, faculty_users):
        for dept in departments:
            candidates = faculty_users.get(dept.code, [])
            if not candidates:
                continue
            # Pick the last candidate as HOD so the dedicated demo "faculty1"
            # account (always candidates[0] for CSE) keeps its faculty role.
            hod_user = candidates[-1]
            username = "hod_cse" if dept.code == "CSE" else self.unique_username(f"hod_{dept.code.lower()}")
            if hod_user.username != username and not User.objects.filter(username=username).exists():
                hod_user.username = username
            hod_user.role = User.Role.HOD
            hod_user.set_password("hod123")
            hod_user.save()
            fac_profile = getattr(hod_user, "faculty_profile", None)
            if fac_profile:
                fac_profile.designation = "HOD"
                fac_profile.save()
            dept.hod = hod_user
            dept.save()

    def create_subjects(self, departments, courses, faculty_users):
        subject_names = [
            "Mathematics", "Programming Fundamentals", "Data Structures", "Digital Electronics",
            "Database Systems", "Operating Systems", "Computer Networks", "Software Engineering",
        ]
        subjects = []
        for course in courses:
            dept = course.department
            handlers = faculty_users.get(dept.code, [])
            for sem in (1, 2):
                for idx in range(3):
                    name = random.choice(subject_names)
                    code = f"{dept.code}{sem}{idx+1}"
                    subject, _ = Subject.objects.get_or_create(
                        code=code,
                        defaults={
                            "name": name, "department": dept, "course": course, "semester_number": sem,
                            "credits": random.choice([3, 4]),
                            "faculty": random.choice(handlers) if handlers else None,
                        },
                    )
                    subjects.append(subject)
        return subjects

    def create_students(self, departments, courses, academic_year, per_dept):
        course_by_dept = {c.department_id: c for c in courses}
        students = []
        counter = 1
        for dept in departments:
            course = course_by_dept.get(dept.id)
            for i in range(per_dept):
                first = random.choice(FIRST_NAMES)
                last = random.choice(LAST_NAMES)
                if dept.code == "CSE" and i == 0:
                    username = "student1"
                else:
                    username = self.unique_username(f"stu_{dept.code.lower()}_{i+1}")
                user, created = User.objects.get_or_create(
                    username=username,
                    defaults={
                        "first_name": first, "last_name": last, "email": f"{username}@collegecrm.edu",
                        "role": User.Role.STUDENT, "phone": f"97{random.randint(10000000, 99999999)}",
                    },
                )
                if created:
                    user.set_password("student123")
                    user.save()
                year = random.choice([1, 1, 2])
                student, _ = Student.objects.get_or_create(
                    user=user,
                    defaults={
                        "date_of_birth": date(random.randint(2004, 2008), random.randint(1, 12), random.randint(1, 28)),
                        "gender": random.choice(["M", "F"]),
                        "address": f"{random.randint(1, 200)}, {random.choice(['MG Road', 'Park Street', 'Church Street', 'Ring Road'])}, City",
                        "department": dept, "course": course, "year": year,
                        # Demo subjects are only seeded for semesters 1-2, so keep student
                        # semester in that range to ensure marks/attendance are generated.
                        "semester": 1 if year == 1 else 2,
                        "academic_year": academic_year, "admission_year": 2026 - (year - 1),
                        "parent_name": f"{random.choice(FIRST_NAMES)} {last}",
                        "parent_phone": f"96{random.randint(10000000, 99999999)}",
                        "emergency_contact": f"95{random.randint(10000000, 99999999)}",
                    },
                )
                students.append(student)
                counter += 1
        return students

    def create_attendance(self, students, subjects):
        subjects_by_course_sem = {}
        for s in subjects:
            subjects_by_course_sem.setdefault((s.course_id, s.semester_number), []).append(s)

        today = timezone.now().date()
        for student in students:
            relevant_subjects = subjects_by_course_sem.get((student.course_id, student.semester), [])
            for subject in relevant_subjects[:3]:
                for days_ago in range(1, 16):
                    att_date = today - timedelta(days=days_ago)
                    if att_date.weekday() >= 5:
                        continue
                    status = random.choices(["PRESENT", "ABSENT", "LATE"], weights=[80, 12, 8])[0]
                    Attendance.objects.get_or_create(
                        student=student, subject=subject, date=att_date,
                        defaults={"status": status, "marked_by": subject.faculty},
                    )

    def create_marks(self, students, subjects):
        subjects_by_course_sem = {}
        for s in subjects:
            subjects_by_course_sem.setdefault((s.course_id, s.semester_number), []).append(s)

        for student in students:
            relevant_subjects = subjects_by_course_sem.get((student.course_id, student.semester), [])
            for subject in relevant_subjects:
                Mark.objects.get_or_create(
                    student=student, subject=subject,
                    defaults={
                        "internal_marks": random.randint(10, 20),
                        "assignment_marks": random.randint(5, 10),
                        "lab_marks": random.randint(10, 20),
                        "practical_marks": random.randint(10, 20),
                        "semester_exam_marks": random.randint(15, 30),
                        "entered_by": subject.faculty,
                    },
                )

    def create_fees(self, students, academic_year):
        fee_types = [
            ("TUITION", 60000), ("EXAM", 3000), ("HOSTEL", 40000), ("TRANSPORT", 8000),
        ]
        today = timezone.now().date()
        for student in students:
            for fee_type, amount in fee_types:
                due = today + timedelta(days=random.choice([-20, 10, 30, 60]))
                fee, created = Fee.objects.get_or_create(
                    student=student, fee_type=fee_type,
                    defaults={"academic_year": academic_year, "total_amount": amount, "due_date": due},
                )
                if created and random.random() < 0.6:
                    paid = round(amount * random.choice([0.5, 1.0, 0.3]), 2)
                    FeePayment.objects.create(
                        fee=fee, amount=paid, payment_method=random.choice(["CARD", "UPI", "NETBANKING"]),
                    )

    def create_complaints(self, students, faculty_users):
        statuses = ["PENDING", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "REJECTED"]
        sample_students = random.sample(students, min(15, len(students)))
        for student in sample_students:
            category = random.choice(list(COMPLAINT_SUBJECTS.keys()))
            status = random.choice(statuses)
            dept_faculty = faculty_users.get(student.department.code, [])
            assigned = random.choice(dept_faculty) if dept_faculty and status != "PENDING" else None
            complaint = Complaint.objects.create(
                student=student, category=category, subject=COMPLAINT_SUBJECTS[category],
                description=f"{COMPLAINT_SUBJECTS[category]}. Please look into this at the earliest convenience.",
                priority=random.choice(["LOW", "MEDIUM", "HIGH", "URGENT"]),
                status=status, assigned_to=assigned,
            )
            ComplaintHistory.objects.create(complaint=complaint, status="PENDING", remarks="Complaint submitted.")
            if status != "PENDING":
                ComplaintHistory.objects.create(complaint=complaint, status=status, changed_by=assigned, remarks="Status updated by staff.")

    def create_announcements(self, departments, faculty_users):
        admin_user = User.objects.filter(role="ADMIN").first()
        samples = [
            ("Mid-Semester Examination Schedule Released", "The mid-semester examination timetable has been published. Please check your department notice board."),
            ("Annual Sports Meet Registration Open", "Registrations for the annual sports meet are now open for all students."),
            ("Fee Payment Deadline Reminder", "Students are reminded to clear pending tuition fees before the due date to avoid late charges."),
            ("Library Extended Hours During Exams", "The central library will remain open until 10 PM during the examination period."),
            ("Guest Lecture on Emerging Technologies", "A guest lecture on emerging technologies will be held in the main auditorium next week."),
        ]
        for i, (title, desc) in enumerate(samples):
            Announcement.objects.get_or_create(
                title=title,
                defaults={
                    "description": desc, "department": random.choice(departments) if i % 2 == 0 else None,
                    "target_year": random.choice([0, 1, 2]), "priority": random.choice(["NORMAL", "HIGH", "URGENT"]),
                    "posted_by": admin_user,
                },
            )

    def create_events(self, students):
        admin_user = User.objects.filter(role="ADMIN").first()
        today = timezone.now().date()
        events_data = [
            ("Tech Fest 2026", "A three-day technical festival featuring hackathons, workshops, and guest talks.", today + timedelta(days=20), "Main Auditorium"),
            ("Cultural Night", "An evening of music, dance, and drama performances by students.", today + timedelta(days=35), "Open Air Theatre"),
            ("Alumni Meet", "Annual alumni gathering and networking event.", today - timedelta(days=10), "College Grounds"),
            ("Career Fair", "Meet recruiters from top companies across various industries.", today + timedelta(days=50), "Convention Centre"),
        ]
        for name, desc, ev_date, venue in events_data:
            event, created = Event.objects.get_or_create(
                name=name,
                defaults={
                    "description": desc, "date": ev_date, "time": "10:00",
                    "venue": venue, "organizer": "Student Affairs Committee",
                    "registration_deadline": ev_date - timedelta(days=3), "created_by": admin_user,
                },
            )
            if created:
                for student in random.sample(students, min(5, len(students))):
                    EventRegistration.objects.get_or_create(event=event, student=student)

    def print_credentials(self):
        self.stdout.write(self.style.SUCCESS("\n========== DEMO LOGIN CREDENTIALS =========="))
        self.stdout.write("Super Admin : username=admin        password=admin123")
        self.stdout.write("HOD         : username=hod_cse      password=hod123")
        self.stdout.write("Faculty     : username=faculty1     password=faculty123")
        self.stdout.write("Student     : username=student1     password=student123")
        self.stdout.write("=============================================\n")
        self.stdout.write("Other faculty/student accounts follow the pattern:")
        self.stdout.write("  faculty_<deptcode>_<n> / faculty123")
        self.stdout.write("  stu_<deptcode>_<n> / student123\n")
