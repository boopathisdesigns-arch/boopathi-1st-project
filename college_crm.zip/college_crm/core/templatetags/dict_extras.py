from django import template

register = template.Library()


@register.filter
def get_item(dictionary, key):
    """Look up a value in a dict by key inside a template."""
    if not dictionary:
        return None
    return dictionary.get(key)
