from django import forms
from academics.forms import BootstrapModelForm
from .models import Fee, FeePayment


class FeeForm(BootstrapModelForm):
    class Meta:
        model = Fee
        fields = ["student", "academic_year", "fee_type", "total_amount", "due_date"]
        widgets = {"due_date": forms.DateInput(attrs={"type": "date"})}


class MockPaymentForm(forms.Form):
    amount = forms.DecimalField(min_value=0.01, widget=forms.NumberInput(attrs={"class": "form-control"}))
    payment_method = forms.ChoiceField(choices=FeePayment.PAYMENT_METHOD_CHOICES, widget=forms.Select(attrs={"class": "form-select"}))
    card_number = forms.CharField(required=False, widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "4242 4242 4242 4242"}))
