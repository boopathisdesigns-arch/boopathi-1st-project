from django.contrib import admin
from .models import Fee, FeePayment


class FeePaymentInline(admin.TabularInline):
    model = FeePayment
    extra = 0


@admin.register(Fee)
class FeeAdmin(admin.ModelAdmin):
    list_display = ("student", "fee_type", "total_amount", "due_date")
    list_filter = ("fee_type", "academic_year")
    search_fields = ("student__student_id",)
    inlines = [FeePaymentInline]


@admin.register(FeePayment)
class FeePaymentAdmin(admin.ModelAdmin):
    list_display = ("transaction_id", "fee", "amount", "payment_method", "paid_on")
