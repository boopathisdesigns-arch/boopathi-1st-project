from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from accounts.decorators import admin_required, student_required
from notifications.utils import notify_user
from .models import Fee, FeePayment
from .forms import FeeForm, MockPaymentForm


@login_required
def fee_list(request):
    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        fees = Fee.objects.filter(student=student) if student else Fee.objects.none()
    else:
        fees = Fee.objects.select_related("student").all()
        query = request.GET.get("q", "")
        if query:
            fees = fees.filter(student__student_id__icontains=query)

    total = sum(f.total_amount for f in fees)
    paid = sum(f.paid_amount for f in fees)
    pending = total - paid

    return render(request, "fees/fee_list.html", {
        "fees": fees, "total": total, "paid": paid, "pending": pending,
    })


@admin_required
def fee_create(request):
    if request.method == "POST":
        form = FeeForm(request.POST)
        if form.is_valid():
            fee = form.save()
            notify_user(fee.student.user, f"A new {fee.get_fee_type_display()} of {fee.total_amount} has been added. Due {fee.due_date}.", category="FEE")
            messages.success(request, "Fee record created.")
            return redirect("fees:fee_list")
    else:
        form = FeeForm()
    return render(request, "fees/fee_form.html", {"form": form})


@login_required
def fee_detail(request, pk):
    fee = get_object_or_404(Fee, pk=pk)
    if request.user.is_student_role and fee.student.user != request.user:
        messages.error(request, "Not authorized.")
        return redirect("core:dashboard")
    return render(request, "fees/fee_detail.html", {"fee": fee, "payments": fee.payments.all()})


@student_required
def make_payment(request, pk):
    fee = get_object_or_404(Fee, pk=pk, student__user=request.user)
    if fee.is_fully_paid:
        messages.info(request, "This fee is already fully paid.")
        return redirect("fees:fee_detail", pk=fee.pk)

    if request.method == "POST":
        form = MockPaymentForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data["amount"]
            if amount > fee.pending_amount:
                messages.error(request, "Amount exceeds pending balance.")
            else:
                FeePayment.objects.create(
                    fee=fee, amount=amount, payment_method=form.cleaned_data["payment_method"],
                    processed_by=request.user,
                )
                notify_user(fee.student.user, f"Payment of {amount} received for {fee.get_fee_type_display()}. (Mock payment - demo only)", category="FEE")
                messages.success(request, "Payment successful (mock transaction, demo only).")
                return redirect("fees:fee_detail", pk=fee.pk)
    else:
        form = MockPaymentForm(initial={"amount": fee.pending_amount})

    return render(request, "fees/make_payment.html", {"fee": fee, "form": form})
