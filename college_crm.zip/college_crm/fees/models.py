from django.db import models
from django.conf import settings
from django.utils import timezone
from students.models import Student
from academics.models import AcademicYear


class Fee(models.Model):
    FEE_TYPE_CHOICES = [
        ("TUITION", "Tuition Fee"),
        ("EXAM", "Exam Fee"),
        ("HOSTEL", "Hostel Fee"),
        ("TRANSPORT", "Transport Fee"),
        ("OTHER", "Other Fee"),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="fees")
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.SET_NULL, null=True, blank=True)
    fee_type = models.CharField(max_length=15, choices=FEE_TYPE_CHOICES)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["due_date"]

    def __str__(self):
        return f"{self.student.student_id} - {self.get_fee_type_display()} - {self.total_amount}"

    @property
    def paid_amount(self):
        return sum(p.amount for p in self.payments.all())

    @property
    def pending_amount(self):
        return self.total_amount - self.paid_amount

    @property
    def is_fully_paid(self):
        return self.pending_amount <= 0

    @property
    def is_overdue(self):
        return not self.is_fully_paid and self.due_date < timezone.now().date()


class FeePayment(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ("CARD", "Card"),
        ("UPI", "UPI"),
        ("NETBANKING", "Net Banking"),
        ("CASH", "Cash"),
        ("CHEQUE", "Cheque"),
    ]

    fee = models.ForeignKey(Fee, on_delete=models.CASCADE, related_name="payments")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=15, choices=PAYMENT_METHOD_CHOICES, default="CARD")
    transaction_id = models.CharField(max_length=50, unique=True, blank=True)
    paid_on = models.DateTimeField(auto_now_add=True)
    processed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        ordering = ["-paid_on"]

    def save(self, *args, **kwargs):
        if not self.transaction_id:
            self.transaction_id = f"TXN{timezone.now().strftime('%Y%m%d%H%M%S')}{self.fee_id or ''}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.transaction_id} - {self.amount}"
