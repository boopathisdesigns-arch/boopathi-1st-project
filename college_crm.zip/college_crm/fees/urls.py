from django.urls import path
from . import views

app_name = "fees"

urlpatterns = [
    path("", views.fee_list, name="fee_list"),
    path("add/", views.fee_create, name="fee_create"),
    path("<int:pk>/", views.fee_detail, name="fee_detail"),
    path("<int:pk>/pay/", views.make_payment, name="make_payment"),
]
