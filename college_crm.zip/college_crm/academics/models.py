from django.db import models
from django.conf import settings


class Department(models.Model):
    name = models.CharField(max_length=150, unique=True)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField(blank=True)
    hod = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="headed_department", limit_choices_to={"role__in": ["HOD", "FACULTY"]},
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Course(models.Model):
    name = models.CharField(max_length=150)
    code = models.CharField(max_length=20, unique=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name="courses")
    duration_years = models.PositiveSmallIntegerField(default=4)

    class Meta:
        ordering = ["department__name", "name"]

    def __str__(self):
        return f"{self.name} ({self.department.code})"


class AcademicYear(models.Model):
    name = models.CharField(max_length=20, unique=True, help_text="e.g. 2026-2027")
    start_date = models.DateField()
    end_date = models.DateField()
    is_current = models.BooleanField(default=False)

    class Meta:
        ordering = ["-start_date"]

    def __str__(self):
        return self.name


class Semester(models.Model):
    SEM_CHOICES = [(i, f"Semester {i}") for i in range(1, 9)]
    number = models.PositiveSmallIntegerField(choices=SEM_CHOICES)
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.CASCADE, related_name="semesters")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["academic_year", "number"]
        unique_together = ("number", "academic_year")

    def __str__(self):
        return f"{self.get_number_display()} - {self.academic_year.name}"


class Subject(models.Model):
    name = models.CharField(max_length=150)
    code = models.CharField(max_length=20, unique=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name="subjects")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="subjects")
    semester_number = models.PositiveSmallIntegerField(choices=Semester.SEM_CHOICES)
    credits = models.PositiveSmallIntegerField(default=3)
    faculty = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="subjects_taught", limit_choices_to={"role__in": ["FACULTY", "HOD"]},
    )

    class Meta:
        ordering = ["course", "semester_number", "name"]

    def __str__(self):
        return f"{self.name} ({self.code})"
