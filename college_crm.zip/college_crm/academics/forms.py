from django import forms
from .models import Department, Course, AcademicYear, Semester, Subject


class BootstrapModelForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            existing = field.widget.attrs.get("class", "")
            if isinstance(field.widget, (forms.CheckboxInput,)):
                field.widget.attrs["class"] = (existing + " form-check-input").strip()
            elif isinstance(field.widget, (forms.Select, forms.SelectMultiple)):
                field.widget.attrs["class"] = (existing + " form-select").strip()
            else:
                field.widget.attrs["class"] = (existing + " form-control").strip()


class DepartmentForm(BootstrapModelForm):
    class Meta:
        model = Department
        fields = ["name", "code", "description", "hod"]


class CourseForm(BootstrapModelForm):
    class Meta:
        model = Course
        fields = ["name", "code", "department", "duration_years"]


class AcademicYearForm(BootstrapModelForm):
    class Meta:
        model = AcademicYear
        fields = ["name", "start_date", "end_date", "is_current"]
        widgets = {
            "start_date": forms.DateInput(attrs={"type": "date"}),
            "end_date": forms.DateInput(attrs={"type": "date"}),
        }


class SemesterForm(BootstrapModelForm):
    class Meta:
        model = Semester
        fields = ["number", "academic_year", "is_active"]


class SubjectForm(BootstrapModelForm):
    class Meta:
        model = Subject
        fields = ["name", "code", "department", "course", "semester_number", "credits", "faculty"]
