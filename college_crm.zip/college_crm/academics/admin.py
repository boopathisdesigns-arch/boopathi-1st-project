from django.contrib import admin
from .models import Department, Course, AcademicYear, Semester, Subject


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "hod")
    search_fields = ("name", "code")


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "department", "duration_years")
    list_filter = ("department",)
    search_fields = ("name", "code")


@admin.register(AcademicYear)
class AcademicYearAdmin(admin.ModelAdmin):
    list_display = ("name", "start_date", "end_date", "is_current")


@admin.register(Semester)
class SemesterAdmin(admin.ModelAdmin):
    list_display = ("number", "academic_year", "is_active")
    list_filter = ("academic_year",)


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "course", "semester_number", "faculty")
    list_filter = ("department", "course", "semester_number")
    search_fields = ("name", "code")
