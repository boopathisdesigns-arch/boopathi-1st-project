from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from accounts.decorators import admin_required, staff_required
from .models import Department, Course, AcademicYear, Semester, Subject
from .forms import DepartmentForm, CourseForm, AcademicYearForm, SemesterForm, SubjectForm


# ---------- Departments ----------

@login_required
def department_list(request):
    query = request.GET.get("q", "")
    departments = Department.objects.all()
    if query:
        departments = departments.filter(name__icontains=query)
    return render(request, "academics/department_list.html", {"departments": departments, "query": query})


@admin_required
def department_create(request):
    if request.method == "POST":
        form = DepartmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Department created successfully.")
            return redirect("academics:department_list")
    else:
        form = DepartmentForm()
    return render(request, "academics/department_form.html", {"form": form, "title": "Add Department"})


@admin_required
def department_update(request, pk):
    department = get_object_or_404(Department, pk=pk)
    if request.method == "POST":
        form = DepartmentForm(request.POST, instance=department)
        if form.is_valid():
            form.save()
            messages.success(request, "Department updated successfully.")
            return redirect("academics:department_list")
    else:
        form = DepartmentForm(instance=department)
    return render(request, "academics/department_form.html", {"form": form, "title": "Edit Department"})


@admin_required
def department_delete(request, pk):
    department = get_object_or_404(Department, pk=pk)
    if request.method == "POST":
        department.delete()
        messages.success(request, "Department deleted.")
        return redirect("academics:department_list")
    return render(request, "core/confirm_delete.html", {"object": department, "cancel_url": "academics:department_list"})


# ---------- Courses ----------

@login_required
def course_list(request):
    courses = Course.objects.select_related("department").all()
    dept = request.GET.get("department")
    if dept:
        courses = courses.filter(department_id=dept)
    return render(request, "academics/course_list.html", {
        "courses": courses, "departments": Department.objects.all(), "selected_dept": dept,
    })


@admin_required
def course_create(request):
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Course created successfully.")
            return redirect("academics:course_list")
    else:
        form = CourseForm()
    return render(request, "academics/course_form.html", {"form": form, "title": "Add Course"})


@admin_required
def course_update(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            form.save()
            messages.success(request, "Course updated successfully.")
            return redirect("academics:course_list")
    else:
        form = CourseForm(instance=course)
    return render(request, "academics/course_form.html", {"form": form, "title": "Edit Course"})


@admin_required
def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == "POST":
        course.delete()
        messages.success(request, "Course deleted.")
        return redirect("academics:course_list")
    return render(request, "core/confirm_delete.html", {"object": course, "cancel_url": "academics:course_list"})


# ---------- Subjects ----------

@login_required
def subject_list(request):
    subjects = Subject.objects.select_related("course", "department", "faculty").all()
    query = request.GET.get("q", "")
    if query:
        subjects = subjects.filter(name__icontains=query) | subjects.filter(code__icontains=query)
    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        if student:
            subjects = subjects.filter(course=student.course, semester_number=student.semester)
    return render(request, "academics/subject_list.html", {"subjects": subjects, "query": query})


@staff_required
def subject_create(request):
    if request.method == "POST":
        form = SubjectForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Subject created successfully.")
            return redirect("academics:subject_list")
    else:
        form = SubjectForm()
    return render(request, "academics/subject_form.html", {"form": form, "title": "Add Subject"})


@staff_required
def subject_update(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    if request.method == "POST":
        form = SubjectForm(request.POST, instance=subject)
        if form.is_valid():
            form.save()
            messages.success(request, "Subject updated successfully.")
            return redirect("academics:subject_list")
    else:
        form = SubjectForm(instance=subject)
    return render(request, "academics/subject_form.html", {"form": form, "title": "Edit Subject"})


@admin_required
def subject_delete(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    if request.method == "POST":
        subject.delete()
        messages.success(request, "Subject deleted.")
        return redirect("academics:subject_list")
    return render(request, "core/confirm_delete.html", {"object": subject, "cancel_url": "academics:subject_list"})


# ---------- Academic Years & Semesters ----------

@login_required
def academic_year_list(request):
    years = AcademicYear.objects.all()
    return render(request, "academics/academic_year_list.html", {"years": years})


@admin_required
def academic_year_create(request):
    if request.method == "POST":
        form = AcademicYearForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Academic year created successfully.")
            return redirect("academics:academic_year_list")
    else:
        form = AcademicYearForm()
    return render(request, "academics/academic_year_form.html", {"form": form, "title": "Add Academic Year"})


@login_required
def semester_list(request):
    semesters = Semester.objects.select_related("academic_year").all()
    return render(request, "academics/semester_list.html", {"semesters": semesters})


@admin_required
def semester_create(request):
    if request.method == "POST":
        form = SemesterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Semester created successfully.")
            return redirect("academics:semester_list")
    else:
        form = SemesterForm()
    return render(request, "academics/semester_form.html", {"form": form, "title": "Add Semester"})
