from django import forms
from academics.forms import BootstrapModelForm
from academics.models import Subject
from .models import Attendance


class AttendanceMarkingForm(forms.Form):
    subject = forms.ModelChoiceField(queryset=Subject.objects.all(), widget=forms.Select(attrs={"class": "form-select"}))
    date = forms.DateField(widget=forms.DateInput(attrs={"type": "date", "class": "form-control"}))


class AttendanceForm(BootstrapModelForm):
    class Meta:
        model = Attendance
        fields = ["student", "subject", "date", "status", "remarks"]
        widgets = {"date": forms.DateInput(attrs={"type": "date"})}
