from datetime import date as date_cls
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q

from accounts.decorators import staff_required, student_required
from academics.models import Subject
from students.models import Student
from notifications.utils import notify_user
from .models import Attendance
from .forms import AttendanceMarkingForm


@staff_required
def mark_attendance(request):
    subject_id = request.GET.get("subject") or request.POST.get("subject")
    date_str = request.GET.get("date") or request.POST.get("date")
    subject = None
    students = []
    selected_date = date_str or date_cls.today().isoformat()

    subjects = Subject.objects.all()
    if request.user.role in ("FACULTY", "HOD"):
        subjects = subjects.filter(faculty=request.user)

    if subject_id:
        subject = get_object_or_404(Subject, pk=subject_id)
        students = Student.objects.filter(course=subject.course, semester=subject.semester_number, is_active=True).select_related("user")

    if request.method == "POST" and subject:
        for student in students:
            status = request.POST.get(f"status_{student.pk}", "PRESENT")
            att, created = Attendance.objects.update_or_create(
                student=student, subject=subject, date=selected_date,
                defaults={"status": status, "marked_by": request.user},
            )
            notify_user(student.user, f"Your attendance for {subject.name} on {selected_date} was marked {status.title()}.", category="ATTENDANCE")
        messages.success(request, f"Attendance saved for {subject.name} on {selected_date}.")
        return redirect(f"/attendance/mark/?subject={subject.pk}&date={selected_date}")

    existing = {}
    if subject:
        existing = {a.student_id: a.status for a in Attendance.objects.filter(subject=subject, date=selected_date)}

    return render(request, "attendance/mark_attendance.html", {
        "subjects": subjects, "subject": subject, "students": students,
        "selected_date": selected_date, "existing": existing,
    })


@login_required
def attendance_list(request):
    subject_id = request.GET.get("subject", "")
    date_str = request.GET.get("date", "")

    if request.user.is_student_role:
        student = getattr(request.user, "student_profile", None)
        records = Attendance.objects.filter(student=student) if student else Attendance.objects.none()
    else:
        records = Attendance.objects.select_related("student", "subject").all()
        if request.user.role in ("FACULTY", "HOD"):
            records = records.filter(subject__faculty=request.user)

    if subject_id:
        records = records.filter(subject_id=subject_id)
    if date_str:
        records = records.filter(date=date_str)

    subjects = Subject.objects.all()
    total = records.count()
    present = records.filter(status="PRESENT").count()
    pct = round((present / total) * 100, 1) if total else 0

    return render(request, "attendance/attendance_list.html", {
        "records": records.order_by("-date")[:200], "subjects": subjects,
        "selected_subject": subject_id, "selected_date": date_str,
        "total": total, "present": present, "pct": pct,
    })
