from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator

from accounts.decorators import staff_required, admin_required, student_required
from .models import Student
from .forms import StudentForm
from attendance.models import Attendance
from marks.models import Mark
from fees.models import Fee


@staff_required
def student_list(request):
    students = Student.objects.select_related("user", "department", "course").all()
    query = request.GET.get("q", "")
    dept = request.GET.get("department", "")
    year = request.GET.get("year", "")

    if query:
        students = students.filter(student_id__icontains=query) | students.filter(user__first_name__icontains=query) | students.filter(user__last_name__icontains=query)
    if dept:
        students = students.filter(department_id=dept)
    if year:
        students = students.filter(year=year)

    if request.user.role == "HOD":
        students = students.filter(department__hod=request.user)

    paginator = Paginator(students.distinct(), 15)
    page = paginator.get_page(request.GET.get("page"))

    from academics.models import Department
    return render(request, "students/student_list.html", {
        "students": page, "query": query, "departments": Department.objects.all(),
        "selected_dept": dept, "selected_year": year,
    })


@login_required
def student_detail(request, pk):
    student = get_object_or_404(Student.objects.select_related("user", "department", "course"), pk=pk)
    if request.user.is_student_role and getattr(request.user, "student_profile", None) != student:
        messages.error(request, "You are not authorized to view this profile.")
        return redirect("core:dashboard")

    attendance_qs = Attendance.objects.filter(student=student)
    total_att = attendance_qs.count()
    present_att = attendance_qs.filter(status="PRESENT").count()
    attendance_pct = round((present_att / total_att) * 100, 1) if total_att else 0

    marks = Mark.objects.filter(student=student).select_related("subject")
    fees = Fee.objects.filter(student=student)

    return render(request, "students/student_detail.html", {
        "student": student, "attendance_pct": attendance_pct, "marks": marks, "fees": fees,
        "total_att": total_att, "present_att": present_att,
    })


@staff_required
def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student profile updated successfully.")
            return redirect("students:student_detail", pk=student.pk)
    else:
        form = StudentForm(instance=student)
    return render(request, "students/student_form.html", {"form": form, "student": student})


@admin_required
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        user = student.user
        student.delete()
        user.delete()
        messages.success(request, "Student removed successfully.")
        return redirect("students:student_list")
    return render(request, "core/confirm_delete.html", {"object": student, "cancel_url": "students:student_list"})


@student_required
def my_profile(request):
    student = get_object_or_404(Student, user=request.user)
    return redirect("students:student_detail", pk=student.pk)
