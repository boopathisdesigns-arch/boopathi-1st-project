from django import forms
from academics.forms import BootstrapModelForm
from .models import Student


class StudentForm(BootstrapModelForm):
    class Meta:
        model = Student
        fields = [
            "date_of_birth", "gender", "address", "department", "course", "year", "semester",
            "academic_year", "admission_year", "parent_name", "parent_phone", "emergency_contact",
            "is_active",
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
            "address": forms.Textarea(attrs={"rows": 2}),
        }
