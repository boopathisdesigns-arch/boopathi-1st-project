from django.db import models
from django.conf import settings
from django.utils import timezone
from academics.models import Department, Course, AcademicYear


def generate_student_id():
    year = timezone.now().year
    prefix = f"STU{year}"
    last = Student.objects.filter(student_id__startswith=prefix).order_by("-student_id").first()
    if last:
        last_num = int(last.student_id.replace(prefix, ""))
        new_num = last_num + 1
    else:
        new_num = 1
    return f"{prefix}{new_num:04d}"


class Student(models.Model):
    GENDER_CHOICES = [("M", "Male"), ("F", "Female"), ("O", "Other")]
    YEAR_CHOICES = [(1, "1st Year"), (2, "2nd Year"), (3, "3rd Year"), (4, "4th Year")]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="student_profile")
    student_id = models.CharField(max_length=20, unique=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    address = models.TextField(blank=True)

    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, related_name="students")
    course = models.ForeignKey(Course, on_delete=models.SET_NULL, null=True, related_name="students")
    year = models.PositiveSmallIntegerField(choices=YEAR_CHOICES, default=1)
    semester = models.PositiveSmallIntegerField(default=1)
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.SET_NULL, null=True, blank=True)
    admission_year = models.PositiveIntegerField(default=timezone.now().year)

    parent_name = models.CharField(max_length=150, blank=True)
    parent_phone = models.CharField(max_length=20, blank=True)
    emergency_contact = models.CharField(max_length=20, blank=True)

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["student_id"]

    def save(self, *args, **kwargs):
        if not self.student_id:
            self.student_id = generate_student_id()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.student_id} - {self.user.get_full_name() or self.user.username}"

    @property
    def full_name(self):
        return self.user.get_full_name() or self.user.username
