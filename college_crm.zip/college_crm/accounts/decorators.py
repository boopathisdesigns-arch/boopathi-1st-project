from functools import wraps
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def role_required(*roles):
    """Allow access only to users whose .role is in `roles`."""
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped(request, *args, **kwargs):
            if request.user.role not in roles:
                raise PermissionDenied("You do not have permission to access this page.")
            return view_func(request, *args, **kwargs)
        return _wrapped
    return decorator


def admin_required(view_func):
    return role_required("ADMIN")(view_func)


def staff_required(view_func):
    """Admin, HOD, or Faculty."""
    return role_required("ADMIN", "HOD", "FACULTY")(view_func)


def admin_or_hod_required(view_func):
    return role_required("ADMIN", "HOD")(view_func)


def student_required(view_func):
    return role_required("STUDENT")(view_func)
