from django.urls import path
from . import views

app_name = "faculty"

urlpatterns = [
    path("", views.faculty_list, name="faculty_list"),
    path("<int:pk>/", views.faculty_detail, name="faculty_detail"),
    path("<int:pk>/edit/", views.faculty_update, name="faculty_update"),
    path("<int:pk>/delete/", views.faculty_delete, name="faculty_delete"),
]
