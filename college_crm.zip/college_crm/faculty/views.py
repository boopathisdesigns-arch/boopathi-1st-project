from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator

from accounts.decorators import admin_required, staff_required
from .models import Faculty
from .forms import FacultyForm
from students.models import Student


@staff_required
def faculty_list(request):
    faculty = Faculty.objects.select_related("user", "department").all()
    query = request.GET.get("q", "")
    dept = request.GET.get("department", "")
    if query:
        faculty = faculty.filter(user__first_name__icontains=query) | faculty.filter(user__last_name__icontains=query) | faculty.filter(faculty_id__icontains=query)
    if dept:
        faculty = faculty.filter(department_id=dept)

    paginator = Paginator(faculty.distinct(), 15)
    page = paginator.get_page(request.GET.get("page"))

    from academics.models import Department
    return render(request, "faculty/faculty_list.html", {
        "faculty_list": page, "query": query, "departments": Department.objects.all(), "selected_dept": dept,
    })


@login_required
def faculty_detail(request, pk):
    fac = get_object_or_404(Faculty.objects.select_related("user", "department"), pk=pk)
    subjects = fac.subjects_handled
    students = Student.objects.filter(course__subjects__faculty=fac.user).distinct()
    return render(request, "faculty/faculty_detail.html", {"fac": fac, "subjects": subjects, "students": students})


@admin_required
def faculty_update(request, pk):
    fac = get_object_or_404(Faculty, pk=pk)
    if request.method == "POST":
        form = FacultyForm(request.POST, instance=fac)
        if form.is_valid():
            form.save()
            messages.success(request, "Faculty profile updated.")
            return redirect("faculty:faculty_detail", pk=fac.pk)
    else:
        form = FacultyForm(instance=fac)
    return render(request, "faculty/faculty_form.html", {"form": form, "fac": fac})


@admin_required
def faculty_delete(request, pk):
    fac = get_object_or_404(Faculty, pk=pk)
    if request.method == "POST":
        user = fac.user
        fac.delete()
        user.delete()
        messages.success(request, "Faculty removed successfully.")
        return redirect("faculty:faculty_list")
    return render(request, "core/confirm_delete.html", {"object": fac, "cancel_url": "faculty:faculty_list"})
