from django.db import models
from django.conf import settings
from django.utils import timezone
from academics.models import Department


def generate_faculty_id():
    year = timezone.now().year
    prefix = f"FAC{year}"
    last = Faculty.objects.filter(faculty_id__startswith=prefix).order_by("-faculty_id").first()
    if last:
        last_num = int(last.faculty_id.replace(prefix, ""))
        new_num = last_num + 1
    else:
        new_num = 1
    return f"{prefix}{new_num:04d}"


class Faculty(models.Model):
    DESIGNATION_CHOICES = [
        ("PROF", "Professor"),
        ("ASSOC", "Associate Professor"),
        ("ASST", "Assistant Professor"),
        ("LECT", "Lecturer"),
        ("HOD", "Head of Department"),
    ]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="faculty_profile")
    faculty_id = models.CharField(max_length=20, unique=True, blank=True)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, related_name="faculty_members")
    designation = models.CharField(max_length=10, choices=DESIGNATION_CHOICES, default="ASST")
    joining_date = models.DateField(default=timezone.now)
    qualification = models.CharField(max_length=200, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["faculty_id"]
        verbose_name_plural = "Faculty"

    def save(self, *args, **kwargs):
        if not self.faculty_id:
            self.faculty_id = generate_faculty_id()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.faculty_id} - {self.user.get_full_name() or self.user.username}"

    @property
    def full_name(self):
        return self.user.get_full_name() or self.user.username

    @property
    def subjects_handled(self):
        return self.user.subjects_taught.all()
