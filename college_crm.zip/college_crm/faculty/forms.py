from academics.forms import BootstrapModelForm
from .models import Faculty


class FacultyForm(BootstrapModelForm):
    class Meta:
        model = Faculty
        fields = ["department", "designation", "joining_date", "qualification", "is_active"]
        widgets = {}


class FacultyCreateForm(BootstrapModelForm):
    class Meta:
        model = Faculty
        fields = ["department", "designation", "joining_date", "qualification"]
